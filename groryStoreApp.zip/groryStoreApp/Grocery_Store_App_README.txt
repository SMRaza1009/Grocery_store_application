1. create MOCKUPs --> it means that, make project screens on notebook for understanding
2. www.moqups.com --> for drawing moqups
3. This grocery store application is "3 Tier Software Application"
4. For brain storming about Database --> www.dbdesigner.net --> create database diagrams
